

function startReading() {
    const speed = document.getElementById('speed').value;
    document.getElementById('startButton').disabled = true;
    document.getElementById('stopButton').disabled = false;

    readingInterval = setInterval(() => {
        if (currentWordIndex < currentWords.length - 1) {
            document.querySelectorAll('#textContainer span')[currentWordIndex].classList.remove('highlight');
            currentWordIndex++;
            document.querySelectorAll('#textContainer span')[currentWordIndex].classList.add('highlight');
        } else {
            clearInterval(readingInterval);
        }
    }, 60000 / speed);
}
