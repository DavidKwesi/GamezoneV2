function redirectToLibrary() {
    window.location.href = "LibraryPage.html";
}

function redirectToReadingSpeedTest() {
    window.location.href = "ReadingSpeedTest.html";
}

function redirectToWordGame() {
    window.location.href = "wordGameT1.html";
}

function redirectToNumberGame() {
    window.location.href = "NumbersGame.html";
}

function redirectToHomepage() {
    window.location.href = "homepage.html";
}
