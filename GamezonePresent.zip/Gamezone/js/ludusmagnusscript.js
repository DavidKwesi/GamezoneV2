function redirectToPerformancePage() {
    window.location.href = "performancePage.html";
}
function redirectToAwards() {
    window.location.href = "Awards.html";
}


function redirectToMyHooks() {
    window.location.href = "UnderConstruction.html";
}

function redirectToCliches() {
    window.location.href = "UnderConstruction.html";
}

function redirectToGeniusJournal() {
    window.location.href = "UnderConstruction.html";
}

function redirectToHomepage() {
    window.location.href = "homepage.html";
}
