function redirectToLudusMagnus() {
    window.location.href = "LudusMagnus.html";
}
