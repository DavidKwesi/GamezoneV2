function redirectToDateGame() {
    window.location.href = "DateGame.html";
}

function redirectToPicturesGame() {
    window.location.href = "PicturesGame.html";
}

function redirectToWordGame() {
    window.location.href = "wordGameT1.html";
}

function redirectToNumberGame() {
    window.location.href = "NumbersGame.html";
}

function redirectToHomepage() {
    window.location.href = "homepage.html";
}
